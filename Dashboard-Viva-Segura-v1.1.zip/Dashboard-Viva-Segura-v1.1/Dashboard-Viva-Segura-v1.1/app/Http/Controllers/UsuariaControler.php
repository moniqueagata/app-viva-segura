<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UsuariaModel;
use Illuminate\Support\Facades\Hash;

class UsuariaControler extends Controller
{

    public function indexApi() {
        $usuarios = UsuariaModel::all();
        return $usuarios;
    }

    public function storeApi(Request $request)
    {
        try {
            $usuaria = new UsuariaModel();

            $usuaria->nome      = $request->nome;
            $usuaria->cpf = preg_replace('/[^0-9]/', '', $request->cpf);
            $usuaria->email     = $request->email;
            $usuaria->senha = Hash::make($request->senha);
            $usuaria->dataNasc  = $request->dataNasc;
            $usuaria->telefone  = $request->telefone;
            $usuaria->id_role   = $request->id_role;

            $usuaria->save();

            return response()->json([
                'message' => 'Usuária cadastrada com sucesso!',
                'data' => $usuaria
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Erro ao cadastrar',
                'details' => $e->getMessage()
            ], 500);
        }
    }

public function loginApi(Request $request)
{
    $cpf = preg_replace('/[^0-9]/', '', $request->cpf);

    $usuaria = UsuariaModel::where('cpf', $cpf)->first();

    return response()->json([
        'cpf_digitado' => $cpf,
        'usuario_encontrado' => $usuaria,
        'senha_digitada' => $request->senha,
        'senha_hash_banco' => $usuaria ? $usuaria->senha : null,
        'senha_confere' => $usuaria ? Hash::check($request->senha, $usuaria->senha) : null
    ]);
}

public function updateApi(Request $request, $id)
{
    try {
        $usuaria = UsuariaModel::find($id);

        if (!$usuaria) {
            return response()->json([
                'message' => 'Usuária não encontrada'
            ], 404);
        }

        $usuaria->nome = $request->nome ?? $usuaria->nome;
        $usuaria->email = $request->email ?? $usuaria->email;
        $usuaria->telefone = $request->telefone ?? $usuaria->telefone;

        $usuaria->save();

        return response()->json([
            'message' => 'Atualizado com sucesso!',
            'data' => $usuaria
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'error' => 'Erro ao atualizar',
            'details' => $e->getMessage()
        ], 500);
    }
}

}
