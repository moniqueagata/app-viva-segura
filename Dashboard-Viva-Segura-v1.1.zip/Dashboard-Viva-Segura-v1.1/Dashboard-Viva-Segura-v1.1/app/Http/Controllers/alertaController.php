<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class alertaController extends Controller
{
    //
}
