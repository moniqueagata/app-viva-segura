<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class botaoPanicoController extends Controller
{
    //
}
