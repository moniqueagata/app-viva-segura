<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class localController extends Controller
{
    //
}
