<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RotaModel extends Model
{
    use HasFactory;

    protected $table = 'tbRota';

    protected $primaryKey = 'id_rota';
    public $fillable = ['origemLatitude', 'origemLongitude', 'destinoLatitude', 'destinoLongitude', 'tempoPrevisto', 'dataCriacao', 'id_usuaria'];
    public function pontos()
    {
        // Uma rota tem muitos pontos
        return $this->hasMany(pontosRotaModel::class, 'id_rota');
    }

    public $timestamps = false;
}
