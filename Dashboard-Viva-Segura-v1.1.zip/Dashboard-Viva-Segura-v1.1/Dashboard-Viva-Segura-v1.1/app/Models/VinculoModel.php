<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VinculoModel extends Model
{
    use HasFactory;

    protected $table = 'tbVinculo';

    public $fillable = ['id', 'dataSolicitacao', 'dataResposta', 'statusVinculo','idUsuario', 'idGuardiao'];
}
