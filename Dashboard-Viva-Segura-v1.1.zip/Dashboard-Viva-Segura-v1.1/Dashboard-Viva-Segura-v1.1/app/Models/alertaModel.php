<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class alertaModel extends Model
{
    use HasFactory;

    protected $table = 'tbAlerta';

    protected $primaryKey = 'id_alerta';

    public $fillable = ['id_alerta', 'latitude', 'longitude', 'statusAlerta', 'desc', 'dataHoraAlerta', 'id_tipoAlerta', 'id_usuaria'];

    public $timestamps = false;
}
