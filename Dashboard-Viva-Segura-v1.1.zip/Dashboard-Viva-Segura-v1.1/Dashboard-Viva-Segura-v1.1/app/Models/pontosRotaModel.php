<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pontosRotaModel extends Model
{
    use HasFactory;

    protected $table = 'tbPontosRota';

    protected $primaryKey = 'id_pontosRota';
    public $fillable = ['latitude', 'longitude', 'id_rota']; // Limpei o que não pertencia aqui

    public function rota()
    {
        // Um ponto pertence a uma rota
        return $this->belongsTo(RotaModel::class, 'id_rota');
    }

    public $timestamps = false;
}
