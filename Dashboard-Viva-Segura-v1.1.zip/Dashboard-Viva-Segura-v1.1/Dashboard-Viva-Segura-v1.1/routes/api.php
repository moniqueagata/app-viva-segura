<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsuariaControler;
use App\Http\Controllers\EnderecoPesquisaController;
use App\Http\Controllers\EnderecoUsuariaController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/usuarios', 'App\Http\Controllers\UsuariaControler@indexApi');
Route::post('/cadastrar', 'App\Http\Controllers\UsuariaControler@storeApi');
Route::post('/login', 'App\Http\Controllers\UsuariaControler@loginApi');

Route::post('/salvarPesquisaEndereco', 'App\Http\Controllers\EnderecoPesquisaController@storeApi');
Route::get('/exibirPesquisaEndereco', 'App\Http\Controllers\EnderecoPesquisaController@index');

Route::post('/salvarEndereco', 'App\Http\Controllers\EnderecoUsuariaController@storeApi');
Route::get('/exibirEndereco', 'App\Http\Controllers\EnderecoUsuariaController@index');

Route::put('/usuaria/{id}', [UsuariaControler::class, 'updateApi']);
Route::put('/salvarEnderecoAlterado/{idEnderecoUsuaria}', [EnderecoUsuariaController::class, 'update']);
Route::delete('/salvarEnderecoAlterado/{id}', [EnderecoUsuariaController::class, 'destroy']);