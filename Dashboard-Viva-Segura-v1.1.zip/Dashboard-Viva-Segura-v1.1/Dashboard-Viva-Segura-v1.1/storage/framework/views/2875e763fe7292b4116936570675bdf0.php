<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(url('css/home.css')); ?>">

    <title>Document</title>
</head>

<body>
    <nav class="navbar">
        <div class="tresBarras">

        </div>
        <div class="tituloDash">

        </div>
        <div class="botoesNav">
        <img src="<?php echo e(url('imagens/icones/darkMode.png')); ?>" alt="Descrição da Imagem" class="icone">
            <img src="<?php echo e(url('imagens/icones/notificacaoWhite.png')); ?>" alt="Descrição da Imagem" class="icone">
            <div class="perfilDados">
                <img src="<?php echo e(url('imagens/fotos/pato.jfif')); ?>" alt="Descrição da Imagem" class="fotoPerfil">
                <div class="nomeUser">
                    <p class="txtUser">Carlos</p>
                    <p class="txtAdmin">Admin</p>
                </div>
                <img src="<?php echo e(url('imagens/icones/setaWhite.png')); ?>" alt="Descrição da Imagem" class="fotoPerfil">
            </div>
            
        </div>

    </nav>
    <section class="principal">
        <nav class="sideBar">
        <img src="<?php echo e(url('imagens/icones/windowWhite.png')); ?>" alt="Descrição da Imagem" class="icone">
            <p>oi</p>
        </nav>
        <div class="conteudo">



        </div>
    </section>
</body>

</html><?php /**PATH C:\Users\userlocal\Downloads\Dashboard-Viva-Segura\resources\views/welcome.blade.php ENDPATH**/ ?>