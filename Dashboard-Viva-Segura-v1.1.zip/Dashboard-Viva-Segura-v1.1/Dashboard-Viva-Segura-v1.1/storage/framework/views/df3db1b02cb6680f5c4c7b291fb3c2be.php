<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DashBoard</title>

    <style>
        :root {
            --bg-roxo: #1a0b63;
            --largura-barra-lateral: 60px;
            --altura-cabecalho: 50px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background-color: #f5f5f5;
        }

        .barra-lateral {
    position: fixed;
    left: 0;
    top: 0;
    height: 100vh;
}.barra-lateral {
            width: var(--largura-barra-lateral);
            background-color: var(--bg-roxo);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 10px;
        }

        .item-navegacao {
            padding: 15px 0;
            cursor: pointer;
            transition: 0.3s;
        }

        .item-navegacao img {
            width: 24px;
            height: 24px;
        }

        .item-navegacao:hover {
            background-color: rgba(255,255,255,0.1);
            width: 100%;
            text-align: center;
        }

        .icone-configuracao {
            margin-top: auto;
            margin-bottom: 20px;
        }

        .container-principal {
    margin-left: var(--largura-barra-lateral);

            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .cabecalho {
    position: fixed;
    top: 0;
    left: var(--largura-barra-lateral);
    right: 0;
    z-index: 1000;

            height: var(--altura-cabecalho);
            background-color: var(--bg-roxo);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            color: white;
        }

        .cabecalho-esquerda {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo {
            width: 30px;
            height: 30px;
            object-fit: contain;
        }

        .cabecalho-direita {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .icone {
            width: 22px;
            cursor: pointer;
        }

        .perfil-usuario {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.8rem;
        }

        .avatar-usuario {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            object-fit: cover;
        }

        .area-conteudo {
    flex: 1;
    background-color: #f8f9fc;
    border-radius: 12px;
    padding: 20px;

    margin-top: calc(var(--altura-cabecalho) + 15px);
    margin-right: 15px;
    margin-bottom: 15px;
    margin-left: 15px;
}


.area-conteudo h2 {
    margin-bottom: 25px;
    color: var(--bg-roxo);
}


.cards {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-bottom: 30px;
}

.card {
    background: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    transition: 0.3s;
    border-left: 4px solid var(--bg-roxo);
}

.card:hover {
    transform: translateY(-5px);
}

.card h3 {
    font-size: 0.9rem;
    color: #666;
    margin-bottom: 10px;
}

.numero {
    font-size: 1.8rem;
    font-weight: bold;
    color: var(--bg-roxo);
}

.vermelho {
    color: #e74c3c;
}


.graficos {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 30px;
}

.grafico-box {
    background: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
}

.grafico-box h3 {
    font-size: 0.9rem;
    color: #666;
    margin-bottom: 10px;
}

.barra {
    width: 100%;
    height: 8px;
    background: #eee;
    border-radius: 20px;
    overflow: hidden;
    margin: 10px 0;
}

.progresso {
    height: 100%;
    background: linear-gradient(90deg, #4facfe, #00f2fe);
    border-radius: 20px;
}

.progresso.roxo {
    background: linear-gradient(90deg, #6a11cb, #2575fc);
}

.progresso.verde {
    background: linear-gradient(90deg, #00c853, #69f0ae);
}

.grafico-box span {
    font-size: 0.8rem;
    color: #888;
}


.atividade {
    background: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
}

.atividade h3 {
    margin-bottom: 15px;
    color: var(--bg-roxo);
}

.atividade ul {
    list-style: none;
}

.atividade li {
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 8px;
    background: #f4f6fb;
    transition: 0.2s;
    font-size: 0.9rem;
}

.atividade li:hover {
    background: #e9ecf7;
}
    </style>
</head>
<body>

    <aside class="barra-lateral">
        <div class="item-navegacao"><img src="/imagens/icones/barraWhite.png"></div>
        <div class="item-navegacao"><img src="/imagens/icones/windowWhite.png"></div>
        <div class="item-navegacao"><img src="/imagens/icones/users.png"></div>
        <div class="item-navegacao"><img src="/imagens/icones/alertaWhite.png"></div>
        <div class="item-navegacao"><img src="/imagens/icones/suporte.png"></div>
        <div class="item-navegacao"><img src=""></div>
        <div class="item-navegacao"><img src=""></div>

        <div class="item-navegacao icone-configuracao">
            <img src="/imagens/icones/engrenagem.png">
        </div>
    </aside>

    <div class="container-principal">

        <header class="cabecalho">
            <div class="cabecalho-esquerda">
                <img src="/imagens/icones/logo.png" class="logo">
                <strong>DashBoard</strong>
            </div>

            <div class="cabecalho-direita">
    <img src="/imagens/icones/notificacaoWhite.png" class="icone">
    <img src="/imagens/icones/darkMode.png" class="icone">
    

    <div class="perfil-usuario">
        <img src="/imagens/fotos/pato.jfif" class="avatar-usuario">
        
        <div>
            <div><strong>Nome</strong></div>
            <div style="font-size: 0.7rem; opacity: 0.8;">admin</div>
           
        </div> <img src="/imagens/icones/setaWhite.png" class="icone">
    </div>
</div>
        </header>

        <main class="area-conteudo">

        <h2>📊 Dashboard de Tecnologia</h2>
    <div class="cards">
        <div class="card">
            <h3>Usuários</h3>
            <p class="numero">1.245</p>
        </div>

        <div class="card">
            <h3>Servidores Ativos</h3>
            <p class="numero">18</p>
        </div>

        <div class="card">
            <h3>Erros Hoje</h3>
            <p class="numero vermelho">23</p>
        </div>

        <div class="card">
            <h3>Requisições</h3>
            <p class="numero">12.8k</p>
        </div>
    </div>

    <div class="graficos">

        <div class="grafico-box">
            <h3>Uso de CPU</h3>
            <div class="barra">
                <div class="progresso" style="width: 70%"></div>
            </div>
            <span>70%</span>
        </div>

        <div class="grafico-box">
            <h3>Uso de Memória</h3>
            <div class="barra">
                <div class="progresso roxo" style="width: 55%"></div>
            </div>
            <span>55%</span>
        </div>

        <div class="grafico-box">
            <h3>Armazenamento</h3>
            <div class="barra">
                <div class="progresso verde" style="width: 80%"></div>
            </div>
            <span>80%</span>
        </div>

    </div>

    <div class="atividade">
        <h3>Atividades recentes</h3>

        <ul>
            <li>✔️ Novo usuário cadastrado</li>
            <li>⚠️ Pico de uso no servidor</li>
            <li>✔️ Backup realizado com sucesso</li>
            <li>❌ Falha em requisição API</li>
        </ul>
    </div>

</main>

    </div>

</body>
</html><?php /**PATH C:\Dashboard-Viva-Segurav4\resources\views/welcome.blade.php ENDPATH**/ ?>